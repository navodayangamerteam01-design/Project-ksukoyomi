const express = require("express");
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const cors = require("cors");
const path = require("path");

const app = express();
app.use(express.json());
app.use(cors());
app.use(express.static(path.join(__dirname, "public")));

const JWT_SECRET = "CASINO_FAMILY_SECRET_2024";
const ADMIN_EMAIL = "navodayangamerteam01@gmail.com";
const ADMIN_PASSWORD = "pritampro235";
const NEWBIE_BALANCE = 90;

mongoose.connect("mongodb://127.0.0.1:27017/casinofamily", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => console.log("✅ MongoDB Connected"))
  .catch(err => console.error("MongoDB Error:", err));

// ─── SCHEMAS ────────────────────────────────────────────────────────────────

const UserSchema = new mongoose.Schema({
  username: { type: String, required: true },
  email:    { type: String, required: true, unique: true },
  password: { type: String, required: true },
  userId:   { type: String, unique: true },
  wallet:   { type: Number, default: NEWBIE_BALANCE },
  totalBet: { type: Number, default: 0 },
  totalWin: { type: Number, default: 0 },
  createdAt:{ type: Date, default: Date.now }
});

const DepositSchema = new mongoose.Schema({
  userId:    { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  amount:    Number,
  utr:       String,
  status:    { type: String, default: "pending" }, // pending, approved, rejected
  createdAt: { type: Date, default: Date.now }
});

const WithdrawSchema = new mongoose.Schema({
  userId:      { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  amount:      Number,
  bankName:    String,
  accountNumber: String,
  ifscCode:    String,
  status:      { type: String, default: "pending" },
  createdAt:   { type: Date, default: Date.now }
});

const BetSchema = new mongoose.Schema({
  userId:    { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  game:      String,
  amount:    Number,
  result:    String,
  profit:    Number,
  createdAt: { type: Date, default: Date.now }
});

const User     = mongoose.model("User",     UserSchema);
const Deposit  = mongoose.model("Deposit",  DepositSchema);
const Withdraw = mongoose.model("Withdraw", WithdrawSchema);
const Bet      = mongoose.model("Bet",      BetSchema);

// ─── HELPERS ────────────────────────────────────────────────────────────────

function generateUserId() {
  return "CF" + Math.floor(100000 + Math.random() * 900000);
}

function authMiddleware(req, res, next) {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(401).json({ message: "No token" });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ message: "Invalid token" });
  }
}

function adminMiddleware(req, res, next) {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(401).json({ message: "No token" });
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    if (!decoded.isAdmin) return res.status(403).json({ message: "Not admin" });
    req.admin = decoded;
    next();
  } catch {
    res.status(401).json({ message: "Invalid token" });
  }
}

function getVipLevel(totalBet) {
  if (totalBet >= 20000) return { level: 3, label: "VIP III", min: 20000, max: 50000, reward: 500 };
  if (totalBet >= 1000)  return { level: 2, label: "VIP II",  min: 1000,  max: 20000, reward: 100 };
  return                        { level: 1, label: "VIP I",   min: 0,     max: 1000,  reward: 50  };
}

// ─── AUTH ROUTES ─────────────────────────────────────────────────────────────

app.post("/api/register", async (req, res) => {
  try {
    const { username, email, password } = req.body;
    if (!username || !email || !password)
      return res.status(400).json({ message: "All fields required" });

    const exists = await User.findOne({ email });
    if (exists) return res.status(400).json({ message: "Email already registered" });

    const hashed = await bcrypt.hash(password, 10);
    const userId = generateUserId();
    const user = new User({ username, email, password: hashed, userId, wallet: NEWBIE_BALANCE });
    await user.save();

    const token = jwt.sign({ id: user._id, email: user.email }, JWT_SECRET, { expiresIn: "7d" });
    res.json({ token, user: { username: user.username, email: user.email, userId: user.userId, wallet: user.wallet } });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ message: "User not found" });

    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(400).json({ message: "Wrong password" });

    const token = jwt.sign({ id: user._id, email: user.email }, JWT_SECRET, { expiresIn: "7d" });
    res.json({ token, user: { username: user.username, email: user.email, userId: user.userId, wallet: user.wallet } });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/admin/login", async (req, res) => {
  const { email, password } = req.body;
  if (email !== ADMIN_EMAIL || password !== ADMIN_PASSWORD)
    return res.status(401).json({ message: "Invalid admin credentials" });
  const token = jwt.sign({ isAdmin: true, email }, JWT_SECRET, { expiresIn: "1d" });
  res.json({ token });
});

// ─── USER ROUTES ─────────────────────────────────────────────────────────────

app.get("/api/profile", authMiddleware, async (req, res) => {
  const user = await User.findById(req.user.id).select("-password");
  res.json(user);
});

app.post("/api/deposit/request", authMiddleware, async (req, res) => {
  const { amount, utr } = req.body;
  if (!amount || !utr) return res.status(400).json({ message: "Amount and UTR required" });
  const deposit = new Deposit({ userId: req.user.id, amount, utr, status: "pending" });
  await deposit.save();
  res.json({ message: "Deposit request submitted. Will be added in 4-5 minutes after admin approval." });
});

app.post("/api/withdraw/request", authMiddleware, async (req, res) => {
  try {
    const { amount, bankName, accountNumber, ifscCode } = req.body;
    const user = await User.findById(req.user.id);
    if (user.wallet < amount) return res.status(400).json({ message: "Insufficient balance" });

    const withdraw = new Withdraw({ userId: req.user.id, amount, bankName, accountNumber, ifscCode, status: "pending" });
    await withdraw.save();
    res.json({ message: "Withdrawal request submitted. Will be processed in 24-48 hours." });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get("/api/history/deposits", authMiddleware, async (req, res) => {
  const deposits = await Deposit.find({ userId: req.user.id }).sort({ createdAt: -1 });
  res.json(deposits);
});

app.get("/api/history/withdrawals", authMiddleware, async (req, res) => {
  const withdrawals = await Withdraw.find({ userId: req.user.id }).sort({ createdAt: -1 });
  res.json(withdrawals);
});

app.get("/api/history/bets", authMiddleware, async (req, res) => {
  const bets = await Bet.find({ userId: req.user.id }).sort({ createdAt: -1 }).limit(50);
  res.json(bets);
});

app.get("/api/stats", authMiddleware, async (req, res) => {
  const user = await User.findById(req.user.id);
  const bets = await Bet.find({ userId: req.user.id });
  const wins  = bets.filter(b => b.result === "win").length;
  const total = bets.length;
  res.json({
    totalBets: total,
    wins,
    losses: total - wins,
    winRate: total > 0 ? ((wins / total) * 100).toFixed(1) : 0,
    totalBetAmount: user.totalBet,
    totalWin: user.totalWin,
    vip: getVipLevel(user.totalBet)
  });
});

// ─── ADMIN ROUTES ────────────────────────────────────────────────────────────

app.get("/api/admin/deposits", adminMiddleware, async (req, res) => {
  const deposits = await Deposit.find().populate("userId", "username email userId").sort({ createdAt: -1 });
  res.json(deposits);
});

app.get("/api/admin/withdrawals", adminMiddleware, async (req, res) => {
  const withdrawals = await Withdraw.find().populate("userId", "username email userId").sort({ createdAt: -1 });
  res.json(withdrawals);
});

app.get("/api/admin/users", adminMiddleware, async (req, res) => {
  const users = await User.find().select("-password").sort({ createdAt: -1 });
  res.json(users);
});

app.post("/api/admin/deposit/:id/approve", adminMiddleware, async (req, res) => {
  const deposit = await Deposit.findById(req.params.id);
  if (!deposit) return res.status(404).json({ message: "Not found" });
  if (deposit.status !== "pending") return res.status(400).json({ message: "Already processed" });

  deposit.status = "approved";
  await deposit.save();
  await User.findByIdAndUpdate(deposit.userId, { $inc: { wallet: deposit.amount } });
  res.json({ message: "Deposit approved and wallet credited" });
});

app.post("/api/admin/deposit/:id/reject", adminMiddleware, async (req, res) => {
  const deposit = await Deposit.findById(req.params.id);
  if (!deposit) return res.status(404).json({ message: "Not found" });
  deposit.status = "rejected";
  await deposit.save();
  res.json({ message: "Deposit rejected" });
});

app.post("/api/admin/withdraw/:id/approve", adminMiddleware, async (req, res) => {
  const withdraw = await Withdraw.findById(req.params.id);
  if (!withdraw) return res.status(404).json({ message: "Not found" });
  if (withdraw.status !== "pending") return res.status(400).json({ message: "Already processed" });

  const user = await User.findById(withdraw.userId);
  if (user.wallet < withdraw.amount) return res.status(400).json({ message: "User has insufficient balance" });

  withdraw.status = "approved";
  await withdraw.save();
  await User.findByIdAndUpdate(withdraw.userId, { $inc: { wallet: -withdraw.amount } });
  res.json({ message: "Withdrawal approved and wallet debited" });
});

app.post("/api/admin/withdraw/:id/reject", adminMiddleware, async (req, res) => {
  const withdraw = await Withdraw.findById(req.params.id);
  if (!withdraw) return res.status(404).json({ message: "Not found" });
  withdraw.status = "rejected";
  await withdraw.save();
  res.json({ message: "Withdrawal rejected" });
});

app.get("/api/admin/stats", adminMiddleware, async (req, res) => {
  const totalUsers     = await User.countDocuments();
  const pendingDeposits  = await Deposit.countDocuments({ status: "pending" });
  const pendingWithdraws = await Withdraw.countDocuments({ status: "pending" });
  const totalDeposited   = await Deposit.aggregate([
    { $match: { status: "approved" } },
    { $group: { _id: null, total: { $sum: "$amount" } } }
  ]);
  res.json({
    totalUsers,
    pendingDeposits,
    pendingWithdraws,
    totalDeposited: totalDeposited[0]?.total || 0
  });
});

// Serve frontend
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(3000, () => console.log("🎰 Casino Family running on http://localhost:3000"));
