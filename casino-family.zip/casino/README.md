# 🎰 Casino Family — Full Stack Gaming Platform

## 📁 FILE STRUCTURE

Paste your project exactly like this:

```
casino-family/
│
├── server.js              ← Main backend server (Node.js + Express + MongoDB)
├── package.json           ← Node dependencies
├── .env                   ← Environment variables (keep secret!)
│
└── public/                ← All frontend files (served by Express)
    ├── index.html         ← Main casino app (Login + Register + Games + Profile)
    ├── admin.html         ← Admin control panel
    │
    ├── css/
    │   └── style.css      ← All styles for the main app
    │
    └── js/
        └── app.js         ← All frontend JavaScript logic
```

---

## 🚀 HOW TO RUN

### Step 1 — Install Node.js
Download from: https://nodejs.org (choose LTS version)

### Step 2 — Install MongoDB
Download from: https://www.mongodb.com/try/download/community
Start MongoDB service before running the app.

### Step 3 — Setup Project
```bash
# Create your project folder
mkdir casino-family
cd casino-family

# Paste all the files as per structure above

# Install dependencies
npm install
```

### Step 4 — Start Server
```bash
npm start
# OR for auto-restart on changes:
npm run dev
```

### Step 5 — Open in Browser
- **Casino Website:** http://localhost:3000
- **Admin Panel:**   http://localhost:3000/admin.html

---

## 🔐 ADMIN CREDENTIALS

| Field    | Value                            |
|----------|----------------------------------|
| Email    | navodayangamerteam01@gmail.com   |
| Password | pritampro235                     |

---

## 💰 FEATURES

### 👤 User Side
- ✅ Real Register / Login (email + password, stored in MongoDB)
- ✅ Wallet with ₹90 welcome bonus for all new users
- ✅ Home page with Aviator, Wingo, Chicken Road, Mines game cards
- ✅ Bottom navigation: Home, Games, Team, Profile
- ✅ Profile with User ID shown at top
- ✅ Deposit section with preset amounts (₹100/200/500/1000/2000/5000)
- ✅ Custom deposit amount input
- ✅ UPI ID shown: 6202821663@fam with copy button
- ✅ UTR paste and submission
- ✅ Withdrawal with Bank selection (all major Indian banks), account, IFSC, amount
- ✅ VIP levels (VIP I/II/III) based on total betting amount
- ✅ Wallet section shows current balance
- ✅ Analysed Statistics (win rate, loss rate, total bets)
- ✅ Game History, Deposit History, Withdrawal History
- ✅ Jackpot counter animation on home page

### 🛡️ Admin Side
- ✅ Secure admin login (separate credentials)
- ✅ Dashboard with live stats (total users, total deposited, pending requests)
- ✅ Deposit approval — credits exact amount to user wallet
- ✅ Deposit rejection
- ✅ Withdrawal approval — deducts exact amount from user wallet
- ✅ Withdrawal rejection
- ✅ Full users list with wallet balances
- ✅ Filter by status (All / Pending / Approved / Rejected)
- ✅ Auto-refresh every 30 seconds
- ✅ Toast notifications for every action

---

## 🎮 ADDING GAME CODE LATER

When you're ready to add real game logic, each game gets its own HTML file:

```
public/
└── games/
    ├── aviator.html
    ├── wingo.html
    ├── chicken.html
    └── mines.html
```

In `app.js`, the `openGame()` function currently shows a placeholder modal.
Replace it to redirect to the game page:

```javascript
function openGame(game) {
  window.location.href = `/games/${game}.html`;
}
```

To record a bet result from a game, call the `/api/bet` endpoint (you can add this to server.js):

```javascript
// POST /api/bet
// Body: { game, amount, result, profit }
// Headers: Authorization: Bearer <token>
```

---

## 🗄️ DATABASE COLLECTIONS

MongoDB `casinofamily` database has these collections:

| Collection | Purpose |
|------------|---------|
| `users`    | User accounts, wallet balances, total bets |
| `deposits` | All deposit requests with UTR and status |
| `withdraws`| All withdrawal requests with bank details |
| `bets`     | Game bet history |

---

## 🌐 DEPLOY TO INTERNET (Optional)

To make your site live:

1. **Railway.app** (free): Upload code, set `MONGO_URI` env var to MongoDB Atlas
2. **MongoDB Atlas**: Free cloud MongoDB at https://cloud.mongodb.com
3. **Render.com**: Another free Node.js hosting option

---

## ⚠️ IMPORTANT NOTES

- Never share your `.env` file publicly
- Change `JWT_SECRET` in `.env` to something complex for production
- MongoDB must be running before starting the server
- Admin panel is at `/admin.html` — keep this URL private
