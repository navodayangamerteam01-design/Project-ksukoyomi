/* ═══════════════════════════════════════════════════════════
   CASINO FAMILY — FRONTEND APP JS
   ═══════════════════════════════════════════════════════════ */

const API = "";  // same origin — server serves frontend

let currentUser = null;
let authToken   = null;

/* ──────────────────────────────────────────────
   INIT
────────────────────────────────────────────── */
window.addEventListener("DOMContentLoaded", () => {
  const token = localStorage.getItem("cf_token");
  const user  = localStorage.getItem("cf_user");
  if (token && user) {
    authToken   = token;
    currentUser = JSON.parse(user);
    showApp();
  } else {
    showAuth();
  }
  animateJackpot();
});

/* ──────────────────────────────────────────────
   AUTH
────────────────────────────────────────────── */
function showAuth() {
  document.getElementById("authPage").style.display = "block";
  document.getElementById("mainApp").style.display  = "none";
}

function showApp() {
  document.getElementById("authPage").style.display = "none";
  document.getElementById("mainApp").style.display  = "flex";
  loadProfileUI();
  loadStats();
  loadHistories();
  switchMainTab("home");
}

function switchTab(tab) {
  document.getElementById("loginForm").style.display    = tab === "login"    ? "block" : "none";
  document.getElementById("registerForm").style.display = tab === "register" ? "block" : "none";
  document.getElementById("loginTab").classList.toggle("active",    tab === "login");
  document.getElementById("registerTab").classList.toggle("active", tab === "register");
  clearMsg();
}

function showMsg(msg, type = "error") {
  const el = document.getElementById("authMsg");
  el.textContent = msg;
  el.className = "auth-msg " + type;
}
function clearMsg() {
  const el = document.getElementById("authMsg");
  el.textContent = "";
  el.className = "auth-msg";
}

async function doLogin() {
  const email    = document.getElementById("loginEmail").value.trim();
  const password = document.getElementById("loginPassword").value;
  if (!email || !password) return showMsg("Please fill all fields");
  try {
    const res  = await fetch(`${API}/api/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password })
    });
    const data = await res.json();
    if (!res.ok) return showMsg(data.message || "Login failed");
    authToken   = data.token;
    currentUser = data.user;
    localStorage.setItem("cf_token", authToken);
    localStorage.setItem("cf_user",  JSON.stringify(currentUser));
    showMsg("Login successful! 🎉", "success");
    setTimeout(showApp, 700);
  } catch {
    showMsg("Server error. Please try again.");
  }
}

async function doRegister() {
  const username = document.getElementById("regUsername").value.trim();
  const email    = document.getElementById("regEmail").value.trim();
  const password = document.getElementById("regPassword").value;
  if (!username || !email || !password) return showMsg("Please fill all fields");
  if (password.length < 6) return showMsg("Password must be at least 6 characters");
  try {
    const res  = await fetch(`${API}/api/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, email, password })
    });
    const data = await res.json();
    if (!res.ok) return showMsg(data.message || "Registration failed");
    authToken   = data.token;
    currentUser = data.user;
    localStorage.setItem("cf_token", authToken);
    localStorage.setItem("cf_user",  JSON.stringify(currentUser));
    showMsg("Account created! Welcome 🎰", "success");
    setTimeout(showApp, 700);
  } catch {
    showMsg("Server error. Please try again.");
  }
}

function logout() {
  if (!confirm("Are you sure you want to logout?")) return;
  localStorage.removeItem("cf_token");
  localStorage.removeItem("cf_user");
  authToken   = null;
  currentUser = null;
  showAuth();
}

/* ──────────────────────────────────────────────
   MAIN TAB NAVIGATION
────────────────────────────────────────────── */
function switchMainTab(tab) {
  document.querySelectorAll(".tab-content").forEach(t => t.classList.remove("active"));
  document.querySelectorAll(".nav-btn").forEach(b => b.classList.remove("active"));
  document.getElementById("tab-" + tab).classList.add("active");
  document.getElementById("nav-" + tab).classList.add("active");
  if (tab === "profile") {
    loadStats();
    loadHistories();
  }
}

/* ──────────────────────────────────────────────
   PROFILE UI
────────────────────────────────────────────── */
function loadProfileUI() {
  if (!currentUser) return;
  document.getElementById("welcomeName").textContent   = currentUser.username || "Player";
  document.getElementById("profileName").textContent   = currentUser.username || "User";
  document.getElementById("profileUid").textContent    = currentUser.userId   || "CF000000";
  document.getElementById("profileEmail").textContent  = currentUser.email    || "";
  document.getElementById("headerBalance").textContent = "₹" + (currentUser.wallet || 0).toFixed(2);
}

async function refreshWallet() {
  try {
    const res  = await authFetch("/api/profile");
    const data = await res.json();
    if (res.ok) {
      currentUser.wallet = data.wallet;
      localStorage.setItem("cf_user", JSON.stringify(currentUser));
      document.getElementById("headerBalance").textContent = "₹" + data.wallet.toFixed(2);
      document.getElementById("walletBigAmt").textContent  = "₹" + data.wallet.toFixed(2);
    }
  } catch {}
}

async function loadStats() {
  try {
    const res  = await authFetch("/api/stats");
    const data = await res.json();
    if (!res.ok) return;
    document.getElementById("statWinRate").textContent  = data.winRate + "%";
    document.getElementById("statLossRate").textContent = (100 - parseFloat(data.winRate)).toFixed(1) + "%";
    document.getElementById("statTotalBets").textContent = data.totalBets;
    const vip = data.vip;
    document.getElementById("vipBadge").textContent      = vip.label;
    document.getElementById("vipCurrentLabel").textContent = vip.label;
    const pct = Math.min(((data.totalBetAmount - vip.min) / (vip.max - vip.min)) * 100, 100);
    document.getElementById("vipExpBar").style.width  = pct + "%";
    document.getElementById("vipExpText").textContent = "₹" + data.totalBetAmount.toLocaleString() + " / ₹" + vip.max.toLocaleString();
  } catch {}
}

async function loadHistories() {
  loadGameHistory();
  loadDepositHistory();
  loadWithdrawHistory();
}

async function loadGameHistory() {
  try {
    const res  = await authFetch("/api/history/bets");
    const data = await res.json();
    const el   = document.getElementById("gameHistoryList");
    if (!res.ok || !data.length) { el.innerHTML = '<div class="empty-state">No bets yet. Start playing! 🎮</div>'; return; }
    el.innerHTML = data.map(b => `
      <div class="history-item">
        <div class="hi-left">
          <div class="hi-game">${gameEmoji(b.game)} ${b.game?.toUpperCase()}</div>
          <div class="hi-date">${formatDate(b.createdAt)}</div>
        </div>
        <div class="hi-right">
          <div class="hi-amount" style="color:${b.result==='win'?'var(--green)':'var(--red)'}">
            ${b.result==='win' ? '+' : '-'}₹${Math.abs(b.profit || b.amount)}
          </div>
          <div class="hi-status status-${b.result}">${b.result?.toUpperCase()}</div>
        </div>
      </div>
    `).join("");
  } catch {}
}

async function loadDepositHistory() {
  try {
    const res  = await authFetch("/api/history/deposits");
    const data = await res.json();
    const el   = document.getElementById("depositHistoryList");
    if (!res.ok || !data.length) { el.innerHTML = '<div class="empty-state">No deposits yet 💳</div>'; return; }
    el.innerHTML = data.map(d => `
      <div class="history-item">
        <div class="hi-left">
          <div class="hi-game">💳 Deposit</div>
          <div class="hi-date">${formatDate(d.createdAt)} · UTR: ${d.utr}</div>
        </div>
        <div class="hi-right">
          <div class="hi-amount" style="color:var(--gold)">₹${d.amount}</div>
          <div class="hi-status status-${d.status}">${d.status?.toUpperCase()}</div>
        </div>
      </div>
    `).join("");
  } catch {}
}

async function loadWithdrawHistory() {
  try {
    const res  = await authFetch("/api/history/withdrawals");
    const data = await res.json();
    const el   = document.getElementById("withdrawHistoryList");
    if (!res.ok || !data.length) { el.innerHTML = '<div class="empty-state">No withdrawals yet 🏧</div>'; return; }
    el.innerHTML = data.map(w => `
      <div class="history-item">
        <div class="hi-left">
          <div class="hi-game">🏧 Withdrawal · ${w.bankName}</div>
          <div class="hi-date">${formatDate(w.createdAt)}</div>
        </div>
        <div class="hi-right">
          <div class="hi-amount" style="color:var(--red)">-₹${w.amount}</div>
          <div class="hi-status status-${w.status}">${w.status?.toUpperCase()}</div>
        </div>
      </div>
    `).join("");
  } catch {}
}

/* ──────────────────────────────────────────────
   SECTIONS / MODALS
────────────────────────────────────────────── */
function openSection(section) {
  if (section === "deposit")  openDeposit();
  if (section === "withdraw") openWithdraw();
  if (section === "vip")      openVip();
  if (section === "wallet")   openWallet();
}

/* ── DEPOSIT ── */
let selectedDepositAmount = 0;

function openDeposit() {
  selectedDepositAmount = 0;
  document.getElementById("depositAmount").value = "";
  document.querySelectorAll(".da-btn").forEach(b => b.classList.remove("selected"));
  showStep("depositStep1");
  document.getElementById("depositDone").style.display = "none";
  document.getElementById("depositModal").style.display = "flex";
}

function selectAmount(amt) {
  selectedDepositAmount = amt;
  document.getElementById("depositAmount").value = amt;
  document.querySelectorAll(".da-btn").forEach(b => {
    b.classList.toggle("selected", parseInt(b.textContent.replace("₹","")) === amt);
  });
}

function depositStep1() {
  const amt = parseInt(document.getElementById("depositAmount").value) || selectedDepositAmount;
  if (!amt || amt < 50) return alert("Minimum deposit is ₹50");
  selectedDepositAmount = amt;
  showStep("depositStep2");
}

function depositStep3() {
  showStep("depositStep3");
}

function showStep(step) {
  ["depositStep1","depositStep2","depositStep3"].forEach(s => {
    document.getElementById(s).style.display = s === step ? "block" : "none";
  });
}

function copyUPI() {
  navigator.clipboard.writeText("6202821663@fam")
    .then(() => alert("UPI ID copied! 📋"))
    .catch(() => {
      const el = document.createElement("textarea");
      el.value = "6202821663@fam";
      document.body.appendChild(el);
      el.select();
      document.execCommand("copy");
      document.body.removeChild(el);
      alert("UPI ID copied! 📋");
    });
}

async function submitDeposit() {
  const utr = document.getElementById("utrInput").value.trim();
  if (!utr) return alert("Please enter UTR number");
  try {
    const res  = await authFetch("/api/deposit/request", "POST", {
      amount: selectedDepositAmount,
      utr
    });
    const data = await res.json();
    if (res.ok) {
      ["depositStep1","depositStep2","depositStep3"].forEach(s => {
        document.getElementById(s).style.display = "none";
      });
      document.getElementById("depositDone").style.display = "block";
      loadDepositHistory();
    } else {
      alert(data.message || "Error submitting deposit");
    }
  } catch {
    alert("Server error. Please try again.");
  }
}

/* ── WITHDRAW ── */
function openWithdraw() {
  document.getElementById("wBankName").value = "";
  document.getElementById("wAccount").value  = "";
  document.getElementById("wIfsc").value     = "";
  document.getElementById("wAmount").value   = "";
  document.querySelector(".withdraw-form").style.display = "flex";
  document.getElementById("withdrawDone").style.display  = "none";
  document.getElementById("withdrawModal").style.display = "flex";
}

async function submitWithdraw() {
  const bankName      = document.getElementById("wBankName").value;
  const accountNumber = document.getElementById("wAccount").value.trim();
  const ifscCode      = document.getElementById("wIfsc").value.trim();
  const amount        = parseInt(document.getElementById("wAmount").value);

  if (!bankName || !accountNumber || !ifscCode || !amount)
    return alert("Please fill all fields");
  if (amount < 100) return alert("Minimum withdrawal is ₹100");

  try {
    const res  = await authFetch("/api/withdraw/request", "POST", { amount, bankName, accountNumber, ifscCode });
    const data = await res.json();
    if (res.ok) {
      document.querySelector(".withdraw-form").style.display = "none";
      document.getElementById("withdrawDone").style.display  = "block";
      loadWithdrawHistory();
    } else {
      alert(data.message || "Error submitting withdrawal");
    }
  } catch {
    alert("Server error. Please try again.");
  }
}

/* ── VIP ── */
function openVip() {
  document.getElementById("vipModal").style.display = "flex";
  loadStats();
}

/* ── WALLET ── */
function openWallet() {
  refreshWallet().then(() => {
    document.getElementById("walletBigAmt").textContent = "₹" + (currentUser.wallet || 0).toFixed(2);
  });
  document.getElementById("walletModal").style.display = "flex";
}

function closeModal(id) {
  document.getElementById(id).style.display = "none";
}

/* ── HISTORY TABS ── */
function switchHTab(tab, btn) {
  document.querySelectorAll(".history-body").forEach(b => b.classList.remove("active"));
  document.querySelectorAll(".htab").forEach(b => b.classList.remove("active"));
  document.getElementById(tab).classList.add("active");
  btn.classList.add("active");
}

/* ── GAME MODAL ── */
const gameInfo = {
  aviator: { name: "AVIATOR",      icon: "✈️",  title: "Aviator" },
  wingo:   { name: "WINGO",        icon: "🎨",  title: "Wingo" },
  chicken: { name: "CHICKEN ROAD", icon: "🐔",  title: "Chicken Road" },
  mines:   { name: "MINES",        icon: "💣",  title: "Mines" }
};

function openGame(game) {
  const info = gameInfo[game] || { name: game.toUpperCase(), icon: "🎮", title: game };
  document.getElementById("gameModalTitle").textContent = info.icon + " " + info.title;
  document.getElementById("gameModalIcon").textContent  = info.icon;
  document.getElementById("gameModalName").textContent  = info.name;
  document.getElementById("gameModal").style.display    = "flex";
}

/* ──────────────────────────────────────────────
   UTILITIES
────────────────────────────────────────────── */
async function authFetch(url, method = "GET", body = null) {
  const opts = {
    method,
    headers: {
      "Content-Type": "application/json",
      "Authorization": "Bearer " + authToken
    }
  };
  if (body) opts.body = JSON.stringify(body);
  return fetch(API + url, opts);
}

function formatDate(dateStr) {
  const d = new Date(dateStr);
  return d.toLocaleDateString("en-IN") + " " + d.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" });
}

function gameEmoji(game) {
  const map = { aviator: "✈️", wingo: "🎨", chicken: "🐔", mines: "💣" };
  return map[game?.toLowerCase()] || "🎮";
}

function animateJackpot() {
  let base = 487250;
  setInterval(() => {
    base += Math.floor(Math.random() * 50);
    const el = document.getElementById("jackpotAmt");
    if (el) el.textContent = "₹" + base.toLocaleString("en-IN");
  }, 3000);
}

/* Close modal on overlay click */
document.addEventListener("click", (e) => {
  if (e.target.classList.contains("modal-overlay")) {
    e.target.style.display = "none";
  }
});
